# 🧪 TableTalk - Tester & QA Quick Start Guide

Welcome to the TableTalk Beta / Testing Release!

Follow these quick steps to launch the app and unlock all Pro & Enterprise features:

---

### Step 1: Launch TableTalk
- **Windows**: Double-click `db_reader_app.exe` (or run `TableTalk_Setup_v1.0.0.exe`).
- **macOS**: Open `TableTalk.app` or mount `TableTalk_v1.0.0.dmg`.
- **Linux**: Execute `TableTalk_Linux.AppImage` or extract tarball bundle.

---

### Step 2: Unlock All Pro Studio & Enterprise Features
By default, TableTalk runs in Community mode. To unlock all features for testing:

1. Launch TableTalk.
2. Click **Settings** (⚙️ icon in top-right navigation or sidebar).
3. Scroll to **Account Subscription & License Key**.
4. Paste one of the following development test license keys:

#### 🔑 Pro Studio Tier Test Key:
```text
TTLK-PRO1-2026-TEST
```
*(Unlocks: AI Performance Query Profiler, Custom System Prompt & Persona Editor, Unlimited Database Connections, Schema Graph Visualizer, YOLO Direct Write Mode)*

#### 🔑 Enterprise Team Tier Test Key:
```text
TTLK-ENT1-2026-TEST
```
*(Unlocks: Everything in Pro Studio + Cryptographic Audit Logs, Automated DB Export/Backups, Enterprise SSO SAML/OIDC Configuration)*

---

### Step 3: Start Testing & Feedback
- Test database connections (PostgreSQL, MySQL, SQLite, MongoDB, Redis).
- Test AI chat assistance, MCP tool execution (`execute_sql_query`), schema graph, and performance profiling.
- Report any feedback or issues to the lead developer!
